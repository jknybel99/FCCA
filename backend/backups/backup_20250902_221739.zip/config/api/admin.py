from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session
from database import SessionLocal
import crud, schemas
from typing import List
import os
import shutil
from datetime import datetime

router = APIRouter(tags=["admin"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# System settings management
@router.get("/settings")
def get_admin_settings(db: Session = Depends(get_db)):
    """Get all system settings"""
    settings = {}
    setting_keys = [
        'school_name', 'school_logo', 'contact_email', 'contact_phone',
        'footer_text', 'system_timezone', 'auto_backup', 'backup_frequency',
        'max_file_size', 'allowed_file_types', 'ntp_enabled', 'ntp_servers', 'ntp_sync_interval'
    ]
    
    for key in setting_keys:
        value = crud.get_system_setting(db, key)
        if value:
            # Convert snake_case to camelCase for frontend compatibility
            if key == 'school_name':
                settings['schoolName'] = value
            elif key == 'school_logo':
                # Make logo URL absolute if it's a relative path
                if value and value.startswith('/'):
                    settings['schoolLogo'] = f"http://localhost:8000{value}"
                else:
                    settings['schoolLogo'] = value
            elif key == 'contact_email':
                settings['contactEmail'] = value
            elif key == 'contact_phone':
                settings['contactPhone'] = value
            elif key == 'footer_text':
                settings['footerText'] = value
            elif key == 'system_timezone':
                settings['systemTimezone'] = value
            elif key == 'auto_backup':
                settings['autoBackup'] = value == 'True'
            elif key == 'backup_frequency':
                settings['backupFrequency'] = value
            elif key == 'max_file_size':
                settings['maxFileSize'] = value
            elif key == 'allowed_file_types':
                settings['allowedFileTypes'] = value
            elif key == 'ntp_enabled':
                settings['ntpEnabled'] = value == 'True'
            elif key == 'ntp_servers':
                settings['ntpServers'] = value
            elif key == 'ntp_sync_interval':
                settings['ntpSyncInterval'] = value
            else:
                settings[key] = value
    
    return settings

@router.post("/settings")
def save_admin_settings(settings: dict, db: Session = Depends(get_db)):
    """Save system settings"""
    try:
        # Convert camelCase to snake_case for database storage
        field_mapping = {
            'schoolName': 'school_name',
            'schoolLogo': 'school_logo',
            'contactEmail': 'contact_email',
            'contactPhone': 'contact_phone',
            'footerText': 'footer_text',
            'systemTimezone': 'system_timezone',
            'autoBackup': 'auto_backup',
            'backupFrequency': 'backup_frequency',
            'maxFileSize': 'max_file_size',
            'allowedFileTypes': 'allowed_file_types',
            'ntpEnabled': 'ntp_enabled',
            'ntpServers': 'ntp_servers',
            'ntpSyncInterval': 'ntp_sync_interval'
        }
        
        for key, value in settings.items():
            if value is not None:
                # Convert camelCase to snake_case if mapping exists
                db_key = field_mapping.get(key, key)
                crud.set_system_setting(db, db_key, str(value))
        return {"message": "Settings saved successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error saving settings: {str(e)}")

@router.post("/upload-logo")
async def upload_logo(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Upload school logo"""
    try:
        # Validate file type
        if not file.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail="File must be an image")
        
        # Create uploads directory if it doesn't exist
        upload_dir = "static/uploads"
        os.makedirs(upload_dir, exist_ok=True)
        
        # Generate unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"logo_{timestamp}_{file.filename}"
        file_path = os.path.join(upload_dir, filename)
        
        # Save file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Save logo path to settings
        logo_url = f"/static/uploads/{filename}"
        crud.set_system_setting(db, "school_logo", logo_url)
        
        return {"logo_url": logo_url, "message": "Logo uploaded successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error uploading logo: {str(e)}")

# NTP Management
@router.get("/ntp/status")
def get_ntp_status():
    """Get current NTP synchronization status"""
    try:
        import ntplib
        import time
        
        # Get NTP settings from database
        db = SessionLocal()
        ntp_enabled = crud.get_system_setting(db, 'ntp_enabled')
        ntp_servers = crud.get_system_setting(db, 'ntp_servers')
        db.close()
        
        if not ntp_enabled or ntp_enabled != 'True':
            return {
                "ntp_enabled": False,
                "status": "disabled",
                "message": "NTP is not enabled"
            }
        
        if not ntp_servers:
            return {
                "ntp_enabled": True,
                "status": "error",
                "message": "No NTP servers configured"
            }
        
        # Parse NTP servers (comma-separated)
        server_list = [s.strip() for s in ntp_servers.split(',') if s.strip()]
        
        # Test NTP servers
        ntp_client = ntplib.NTPClient()
        results = []
        
        for server in server_list[:3]:  # Test up to 3 servers
            try:
                response = ntp_client.request(server, timeout=2)
                offset = response.offset
                delay = response.delay
                results.append({
                    "server": server,
                    "offset": offset,
                    "delay": delay,
                    "status": "reachable"
                })
            except Exception as e:
                results.append({
                    "server": server,
                    "status": "unreachable",
                    "error": str(e)
                })
        
        # Calculate average offset if we have successful responses
        successful_results = [r for r in results if r["status"] == "reachable"]
        if successful_results:
            avg_offset = sum(r["offset"] for r in successful_results) / len(successful_results)
            status = "synchronized" if abs(avg_offset) < 1.0 else "drift_detected"
        else:
            avg_offset = None
            status = "error"
        
        return {
            "ntp_enabled": True,
            "status": status,
            "servers": results,
            "average_offset": avg_offset,
            "local_time": time.time(),
            "message": f"NTP status: {status}"
        }
        
    except ImportError:
        return {
            "ntp_enabled": False,
            "status": "error",
            "message": "ntplib not installed. Install with: pip install ntplib"
        }
    except Exception as e:
        return {
            "ntp_enabled": False,
            "status": "error",
            "message": f"Error checking NTP status: {str(e)}"
        }

@router.post("/ntp/sync")
def sync_with_ntp():
    """Manually trigger NTP synchronization"""
    try:
        import ntplib
        import time
        
        # Get NTP settings from database
        db = SessionLocal()
        ntp_enabled = crud.get_system_setting(db, 'ntp_enabled')
        ntp_servers = crud.get_system_setting(db, 'ntp_servers')
        db.close()
        
        if not ntp_enabled or ntp_enabled != 'True':
            raise HTTPException(status_code=400, detail="NTP is not enabled")
        
        if not ntp_servers:
            raise HTTPException(status_code=400, detail="No NTP servers configured")
        
        # Parse NTP servers
        server_list = [s.strip() for s in ntp_servers.split(',') if s.strip()]
        
        # Try to sync with first available server
        ntp_client = ntplib.NTPClient()
        sync_result = None
        
        for server in server_list:
            try:
                response = ntp_client.request(server, timeout=3)
                offset = response.offset
                delay = response.delay
                
                sync_result = {
                    "server": server,
                    "offset": offset,
                    "delay": delay,
                    "timestamp": time.time()
                }
                break
                
            except Exception as e:
                continue
        
        if not sync_result:
            raise HTTPException(status_code=500, detail="Could not sync with any NTP server")
        
        # Store the sync result for reference
        crud.set_system_setting(db, 'last_ntp_sync', str(sync_result))
        
        return {
            "message": "NTP synchronization successful",
            "sync_result": sync_result
        }
        
    except ImportError:
        raise HTTPException(status_code=500, detail="ntplib not installed. Install with: pip install ntplib")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during NTP sync: {str(e)}")

@router.get("/ntp/servers")
def get_ntp_servers():
    """Get list of recommended NTP servers"""
    return {
        "recommended_servers": [
            "pool.ntp.org",
            "time.nist.gov",
            "time.google.com",
            "time.windows.com",
            "time.apple.com"
        ],
        "note": "Use comma-separated values when configuring multiple servers"
    }

@router.post("/backup")
def create_backup(db: Session = Depends(get_db)):
    """Create a database backup"""
    try:
        # Implementation for database backup
        return {"message": "Backup created successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating backup: {str(e)}")

@router.post("/clear-cache")
def clear_cache(db: Session = Depends(get_db)):
    """Clear system cache"""
    try:
        # Implementation for clearing cache
        return {"message": "Cache cleared successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error clearing cache: {str(e)}")

@router.get("/system-info")
def get_system_info():
    """Get system information"""
    try:
        import platform
        import psutil
        
        return {
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "cpu_count": psutil.cpu_count(),
            "memory_total": psutil.virtual_memory().total,
            "memory_available": psutil.virtual_memory().available,
            "disk_usage": psutil.disk_usage('/')._asdict()
        }
    except ImportError:
        return {
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "note": "Install psutil for detailed system information"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error getting system info: {str(e)}")