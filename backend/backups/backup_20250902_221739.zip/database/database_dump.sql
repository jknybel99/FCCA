BEGIN TRANSACTION;
CREATE TABLE special_schedule_dates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                special_schedule_id INTEGER NOT NULL,
                date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (special_schedule_id) REFERENCES special_schedules (id) ON DELETE CASCADE,
                UNIQUE(special_schedule_id, date)
            );
DELETE FROM "sqlite_sequence";
COMMIT;
